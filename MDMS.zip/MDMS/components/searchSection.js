app.component('mdms-search-section' , {
    template:
    /*html*/
    `
    
    <div class="flex-container section_header" >
        <div >
            <p class="section_header_detail">SucheFilter</p>
        </div>
        <div class="section_header_button">
            <button>Excel Export</button>
        </div>  
    </div>
    <div class="section_body">
        <div>
            <form>
                <input id="searchInputField" type="text" placeholder="Search..">
                <button> submit </button>
            </form>
            
        </div>
    </div>

    `,
    data() {
        return {
        }
    },
    mehtods: {
        
    }
})