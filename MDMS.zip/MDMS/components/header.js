app.component('mdms-header' , {
    template:
    /*html*/
    `
    <div class="flex-container">
        <div class="flex-inner-container">
            <button class="quality-sec-button">Quality</button>
            <div class="flex-container">
                <button class="quality-sec-button">-> Emittent</button>
                <button class="quality-sec-button">Instrument</button>
                <button class="quality-sec-button">Äquivalenzen</button>
            </div>
        </div>
        <mdms-search-buttons></mdms-search-buttons>
        <div class="flex-inner-container">
        <button>Adminstration</button>
        </div>
    </div>
    `
})