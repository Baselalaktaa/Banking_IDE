app.component('mdms-search-buttons' , {
    template:
    /*html*/
    `<div class="flex-inner-container ">
    <button v-on:click="searchClicked"  class="searchButton "> Suche </button>
    <div v-if="isHidden" class="flex-container"> 
        <button> -> Emittent </button>
        <button> -> Instrument </button>
    </div>
    </div>
    `,
    data () {
        return {
            isHidden: false
        }
    },
    methods: {
        searchClicked () {
            this.isHidden = !this.isHidden
            console.log(this.isHidden)
        }
    }
})